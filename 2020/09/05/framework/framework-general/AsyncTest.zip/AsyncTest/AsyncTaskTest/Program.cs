﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncTaskTest
{
    class Program
    {

        static void Main(string[] args)
        {
            //TaskTest_NonGeneric.Test();
            //TaskTest.Test();
            //TaskSchedulerTest.Test();
            //ContinueWithTest.Test();
            ContinueWithTest.Test1();

            Console.ReadKey();
        }
    }
}
