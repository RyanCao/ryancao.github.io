﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncTaskTest
{
    /// <summary>
    /// 任务组合
    /// </summary>
    class ContinueWithTest
    {
        private static readonly Random rand = new Random();
        static void TaskMethod(string taskname)
        {
            Console.WriteLine("Task {0} is running on a thread id {1}. Is thread pool thread: {2}",
                        taskname, Thread.CurrentThread.ManagedThreadId, Thread.CurrentThread.IsThreadPoolThread);
            int sleepTime = rand.Next(100, 500);
            Thread.Sleep(sleepTime);
            Console.WriteLine("Task {0} Completed!",taskname);
        }

        static Task CreateTask(string name)
        {
            return new Task(() => TaskMethod(name));
        }

        public static void Test()
        {
            Task task1 = CreateTask("T1");
            Task task2 = CreateTask("T2");
            
            task1.Start();

            Console.WriteLine("主线程执行其他处理");
            task1.ContinueWith(t => { 
                task2.Start(); 
            });

        }

        public static void Test1()
        {
            Task task1 = CreateTask("T1");
            Task task2 = CreateTask("T2");
            Task task3 = CreateTask("T3");
            Task task4 = CreateTask("T4");

            // t1->[t2,t3]->t4

            task1.Start();

            Console.WriteLine("主线程执行其他处理");
            task1.ContinueWith(t => {
                task2.Start();
                task3.Start();
            });

            Task t23 = Task.WhenAll(task2, task3);
            t23.ContinueWith(t =>
            {
                task4.Start();
            });

        }
    }
}
