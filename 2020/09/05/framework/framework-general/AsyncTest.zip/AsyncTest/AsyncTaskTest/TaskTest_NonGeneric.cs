﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncTaskTest
{
    /// <summary>
    /// 测试不带泛型参数的Task
    /// </summary>
    public class TaskTest_NonGeneric
    {
        static void TaskMethod(string taskname)
        {
            Console.WriteLine("Task {0} is running on a thread id {1}. Is thread pool thread: {2}",
                        taskname, Thread.CurrentThread.ManagedThreadId, Thread.CurrentThread.IsThreadPoolThread);
            Thread.Sleep(500);
        }

        public static void Test()
        {
            Task task1 = new Task(() => TaskMethod("T1")); //TaskMethod 具体任务操作
            task1.Start();
            Task.WaitAll(task1);//等待任务结束

            Task.Factory.StartNew(() => TaskMethod("T2"));    //直接异步的方法

            var t3 = Task.Factory.StartNew(() => TaskMethod("T3"));
        }
    }
}
