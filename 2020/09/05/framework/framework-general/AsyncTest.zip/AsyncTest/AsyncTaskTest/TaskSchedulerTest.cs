﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;


namespace AsyncTaskTest
{
    /// <summary>
    /// 自定义任务调度器
    /// 将任务 用同一个线程进行调度
    /// </summary>
    class MyTaskScheduler : TaskScheduler
    {
        public static new TaskScheduler Current { get; } = new MyTaskScheduler();
        public static new TaskScheduler Default { get; } = Current;

        /// <summary>
        /// 线程安全集合
        /// </summary>
        private readonly BlockingCollection<Task> m_queue = new BlockingCollection<Task>();

        MyTaskScheduler()
        {
            Thread thread = new Thread(Run);
            thread.IsBackground = true;//设为为后台线程，当主线程结束时线程自动结束
            thread.Start();
        }

        private void Run()
        {
            Console.WriteLine($"MyTaskScheduler, ThreadID: {Thread.CurrentThread.ManagedThreadId}");
            Task t;
            while (m_queue.TryTake(out t, Timeout.Infinite))
            {
                TryExecuteTask(t);//在当前线程执行Task
            }
        }

        protected override IEnumerable<Task> GetScheduledTasks()
        {
            return m_queue;
        }


        /// <summary>
        /// t.Start(MyTaskScheduler.Current)时，将Task加入到队列中
        /// </summary>
        /// <param name="task"></param>
        protected override void QueueTask(Task task)
        {
            m_queue.Add(task);
        }

        //当执行该函数时，程序正在尝试以同步的方式执行Task代码
        protected override bool TryExecuteTaskInline(Task task, bool taskWaspreviouslyQueued)
        {
            return false;
        }
    }

    /// <summary>
    /// 任务调度器测试
    /// </summary>
    class TaskSchedulerTest
    {
        static void TaskMethod(string taskname)
        {
            Console.WriteLine("Task {0} is running on a thread id {1}. Is thread pool thread: {2}",
                        taskname, Thread.CurrentThread.ManagedThreadId, Thread.CurrentThread.IsThreadPoolThread);
            Thread.Sleep(500);
        }
        static Task CreateTask(string name)
        {
            return new Task(() => TaskMethod(name));
        }

        public static void Test()
        {
            Console.WriteLine($"Main, ThreadID: {Thread.CurrentThread.ManagedThreadId}");
            for (int i = 0; i < 10; i++)
            {
                var t = CreateTask("T" + (i+1));
                t.Start(MyTaskScheduler.Current);
            }
        }
    }
}
