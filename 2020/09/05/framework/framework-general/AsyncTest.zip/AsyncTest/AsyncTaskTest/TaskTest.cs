﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncTaskTest
{
    public class TaskTest
    {
        static int TaskMethod(string taskname)
        {
            Console.WriteLine("Task {0} is running on a thread id {1}. Is thread pool thread: {2}",
                        taskname, Thread.CurrentThread.ManagedThreadId, Thread.CurrentThread.IsThreadPoolThread);
            Thread.Sleep(500);
            return 100;
        }
        static Task<int> CreateTask(string name)
        {
            return new Task<int>(() => TaskMethod(name));
        }

        public static void Test()
        {
            TaskMethod("Main Thread Task");

            Task<int> task = CreateTask("T1");
            task.Start();
            int result = task.Result;
            Console.WriteLine("T1 Result is: {0}", result);

            task = CreateTask("T2");
            //该任务会运行在主线程中
            task.RunSynchronously();
            result = task.Result;
            Console.WriteLine("T2 Result is: {0}", result);

        }
    }
}
