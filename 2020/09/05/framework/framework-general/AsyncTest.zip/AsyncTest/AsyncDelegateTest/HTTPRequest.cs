﻿using System.Threading;

namespace AsyncDelegateTest
{
    /// <summary>
    /// HTTP 回应
    /// </summary>
    public class HTTPResponse
    {
        /// <summary>
        /// 回应错误码
        /// </summary>
        public int errorCode;
        /// <summary>
        /// 回应消息串
        /// </summary>
        public string response;
    }
    /// <summary>
    /// 示例程序
    /// </summary>
    public class HTTPRequest
    {
        /// <summary>
        /// 请求成功 委托定义
        /// </summary>
        /// <param name="originalRequest"></param>
        /// <param name="response"></param>
        public delegate void OnRequestFinishedDelegate(HTTPRequest originalRequest, HTTPResponse response);
        /// <summary>
        /// 下载进度委托示例
        /// </summary>
        /// <param name="originalRequest"></param>
        /// <param name="response"></param>
        public delegate void OnDownloadProgressDelegate(HTTPRequest originalRequest, long downloaded, long downloadLength);
        /// <summary>
        /// 上传进度委托示例
        /// </summary>
        /// <param name="originalRequest"></param>
        /// <param name="uploaded"></param>
        /// <param name="uploadLength"></param>
        public delegate void OnUploadProgressDelegate(HTTPRequest originalRequest, long uploaded, long uploadLength);

        /// <summary>
        /// 异步回调方法
        /// </summary>
        public OnRequestFinishedDelegate onRequestFinished;
        public OnDownloadProgressDelegate onDownloadProgress;
        public OnUploadProgressDelegate onUploadProgress;

        public string httptype;
        public string url;
    }

    public static class HTTP
    {
        /// <summary>
        /// 测试代码
        /// </summary>
        /// <param name="httpRequest"></param>
        public static void Send(this HTTPRequest httpRequest)
        {
            ThreadStart reqestSimulate = () =>
            {
                int length = 10;
                if (httpRequest.onUploadProgress != null)
                {
                    for (int i = 0; i < length; i++)
                    {
                        Thread.Sleep(50);
                        httpRequest.onUploadProgress.Invoke(httpRequest, i, length);
                    }
                }
                if (httpRequest.onDownloadProgress != null)
                {
                    for (int i = 0; i < length; i++)
                    {
                        Thread.Sleep(50);
                        httpRequest.onDownloadProgress.Invoke(httpRequest, i, length);
                    }
                }
                if (httpRequest.onRequestFinished != null)
                {
                    HTTPResponse response = new HTTPResponse();
                    response.response = httpRequest.url + ":responsed!";
                    response.errorCode = 200;
                    httpRequest.onRequestFinished.Invoke(httpRequest, response);
                }
            };

            Thread thread = new Thread(reqestSimulate);
            thread.Start();
        }

    }

}
