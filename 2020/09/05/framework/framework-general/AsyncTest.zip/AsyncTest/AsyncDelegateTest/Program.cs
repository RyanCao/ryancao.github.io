﻿using System;

namespace AsyncDelegateTest
{
    class Program
    {
        static void Main(string[] args)
        {
            AsyncDelegateTest();
        }
        /// <summary>
        /// 异步委托函数测试
        /// </summary>
        static void AsyncDelegateTest()
        {
            HTTPRequest request = new HTTPRequest();
            request.url = "http://www.baidu.com";
            request.httptype = "get";
            request.onDownloadProgress = (r, a, l) =>
            {
                Console.WriteLine(string.Format("onDownloadProgress:{0}/{1}", a, l));
            };
            request.onUploadProgress = (r, a, l) =>
            {
                Console.WriteLine(string.Format("onUploadProgress:{0}/{1}", a, l));
            };
            request.onRequestFinished = (request, respone) =>
            {
                Console.WriteLine(string.Format("onRequestFinished:{0}", respone.response));
            };
            request.Send();
            Console.WriteLine("request.Send!");

            Console.ReadKey();
        }
    }
}
