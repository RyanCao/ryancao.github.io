﻿using System;

namespace AsyncTest
{
    class Program
    {
        static void Main(string[] args)
        {
            AsyncTest_NonGeneric.Test();
            //AsyncTest.Test();
            AsyncPromiseTest.Test();
            Console.ReadKey();
        }
    }
}
