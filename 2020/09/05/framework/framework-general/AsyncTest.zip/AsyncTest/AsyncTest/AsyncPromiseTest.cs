﻿using RSG;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncTest
{
    /// <summary>
    /// Promise
    /// </summary>
    class AsyncPromiseTest
    {
        private static readonly Random rand = new Random();
        static void TaskMethod(string taskname, Promise p)
        {
            Console.WriteLine("Task {0} is running on a thread id {1}. Is thread pool thread: {2}",
                        taskname, Thread.CurrentThread.ManagedThreadId, Thread.CurrentThread.IsThreadPoolThread);
            Thread.Sleep(rand.Next(100, 500));
            Console.WriteLine("Task {0} Completed", taskname);
            p.Resolve();
        }

        static Task CreateTask(string name, Promise p)
        {
            return new Task(() => TaskMethod(name, p));
        }

        /// <summary>
        /// void 返回值的 async 
        /// t1->(t2,t3)->t4
        /// </summary>
        static IPromise CalcAsync()
        {
            Promise p1 = new Promise();
            Promise p2 = new Promise();
            Promise p3 = new Promise();
            Promise p4 = new Promise();

            Task task1 = CreateTask("T1", p1);
            Task task2 = CreateTask("T2", p2);
            Task task3 = CreateTask("T3", p3);
            Task task4 = CreateTask("T4", p4);

            p1.Then(() =>
            {
                task2.Start();
                task3.Start();
            });

            Promise.All(p2, p3).Then(() =>
            {
                task4.Start();
            });

            task1.Start();

            return p4.Then(() =>
            {

            });
        }

        public static void Test()
        {
            Console.WriteLine("Main Thread AsyncPromiseTest Before");
            var ipromise = CalcAsync();  // void 类型不能 接受返回值
            ipromise.Then(() =>
            {
                Console.WriteLine("Calc Completed.");
            });
            Console.WriteLine("Main Thread AsyncPromiseTest After");
        }
    }
}
