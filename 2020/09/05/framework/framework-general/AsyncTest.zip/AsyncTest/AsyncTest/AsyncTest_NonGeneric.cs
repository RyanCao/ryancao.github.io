﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncTest
{
    public class AsyncTest_NonGeneric
    {
        private static readonly Random rand = new Random();
        static void TaskMethod(string taskname)
        {
            Console.WriteLine("Task {0} is running on a thread id {1}. Is thread pool thread: {2}",
                        taskname, Thread.CurrentThread.ManagedThreadId, Thread.CurrentThread.IsThreadPoolThread);
            Thread.Sleep(rand.Next(100,500));
            Console.WriteLine("Task {0} Completed", taskname);
        }

        static Task CreateTask(string name)
        {
            return new Task(() => TaskMethod(name));
        }

        /// <summary>
        /// void 返回值的 async 
        /// t1->(t2,t3)->t4
        /// </summary>
        static async void CalcAsync()
        {
            Task task1 = CreateTask("T1");
            task1.Start();
            await task1;
            Console.WriteLine("T1 Completed !" + "CalcAsync Thread ID is :" + Thread.CurrentThread.ManagedThreadId);

            Task task2 = CreateTask("T2");
            task2.Start();
            Task task3 = CreateTask("T3");
            task3.Start();

            await task2;
            Console.WriteLine("T2 Completed !" + "CalcAsync Thread ID is :" + Thread.CurrentThread.ManagedThreadId);
            await task3;
            Console.WriteLine("T3 Completed !" + "CalcAsync Thread ID is :" + Thread.CurrentThread.ManagedThreadId);
            
            Task task4 = CreateTask("T4");
            task4.Start();
            await task4;

            Console.WriteLine("CalcAsync Completed !" + "CalcAsync Thread ID is :" + Thread.CurrentThread.ManagedThreadId);
        }

        public static void Test()
        {
            Console.WriteLine("Main Thread AsyncTest_NonGeneric Before");
            CalcAsync();  // void 类型不能 接受返回值
            Console.WriteLine("Main Thread AsyncTest_NonGeneric After");
        }
    }
}
