﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncTest
{
    public class AsyncTest
    {
        private static readonly Random rand = new Random();
        static int TaskMethod(string taskname, int p)
        {
            Console.WriteLine("Task {0} is running on a thread id {1}. Is thread pool thread: {2}",
                        taskname, Thread.CurrentThread.ManagedThreadId, Thread.CurrentThread.IsThreadPoolThread);
            Thread.Sleep(rand.Next(100, 500));
            Console.WriteLine("Task {0} Completed", taskname);
            return 100 * p;
        }

        static Task<int> CreateTask(string name, int p)
        {
            return new Task<int>(() => TaskMethod(name, p));
        }

        /// <summary>
        /// void 返回值的 async 
        /// t1->(t2,t3)->t4
        /// </summary>
        static async Task<int> CalcAsync()
        {
            Task<int> task1 = CreateTask("T1", 1);
            task1.Start();
            int ret1 = await task1;
            Console.WriteLine("T1 Completed !" + "ret1 :" + ret1);

            Task<int> task2 = CreateTask("T2", ret1);
            task2.Start();
            Task<int> task3 = CreateTask("T3", ret1);
            task3.Start();

            int ret2 = await task2;
            Console.WriteLine("T2 Completed !" + "ret2 :" + ret2);
            int ret3 = await task3;
            Console.WriteLine("T3 Completed !" + "ret3 :" + ret3);

            Task<int> task4 = CreateTask("T4", ret2 + ret3);
            task4.Start();
            int ret4 = await task4;
            Console.WriteLine("T4 Completed !" + "ret4 :" + ret4);
            return ret4;
        }

        public static void Test()
        {
            var task = CalcAsync();  // void 类型不能 接受返回值
            task.ContinueWith(t =>
            {
                Console.WriteLine("Calc Completed.Ret: {0}", t.Result);
            });
        }
    }
}
