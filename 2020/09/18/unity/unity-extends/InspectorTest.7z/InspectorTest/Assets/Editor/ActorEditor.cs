﻿using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(Actor))]
public class ActorEditor : Editor
{
    enum WeaponID
    {
        Sword,
        Dagger,
        Bow,
        MagicBook,
        MagicBall,
    }

    bool showWeapons;
    Actor actor;

    void OnEnable()
    {
        actor = (Actor)target;
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();
        //空两行
        EditorGUILayout.Space();
        EditorGUILayout.Space();

        //绘制palyer的基本信息
        EditorGUILayout.LabelField("Base Info");

        showWeapons = EditorGUILayout.Foldout(showWeapons, "Weapons");
        if (showWeapons)
        {
            WeaponID weapon1ID = (WeaponID)actor.weapon1Id;
            weapon1ID = (WeaponID)EditorGUILayout.EnumPopup("Weapon 1 ID", weapon1ID);
            actor.weapon1Id = (int)weapon1ID;

            WeaponID weapon2ID = (WeaponID)actor.weapon2Id;
            weapon2ID = (WeaponID)EditorGUILayout.EnumPopup("Weapon 2 ID", weapon2ID);
            actor.weapon2Id = (int)weapon2ID;
        }

        //空三行
        EditorGUILayout.Space();
        EditorGUILayout.Space();
        EditorGUILayout.Space();

        //使用滑块绘制 Player 生命值
        actor.health = (int)EditorGUILayout.Slider("Health", actor.health, 0, 100);
        //根据生命值设置生命条的背景颜色
        if (actor.health < 20)
        {
            GUI.color = Color.red;
        }
        else if (actor.health > 80)
        {
            GUI.color = Color.green;
        }
        else
        {
            GUI.color = Color.gray;
        }
        //指定生命值的宽高
        Rect progressRect = GUILayoutUtility.GetRect(50, 50);
        //绘制生命条
        EditorGUI.ProgressBar(progressRect, actor.health / 100.0f, "Health");

        int speed = EditorGUILayout.IntField("Speed", actor.Speed);
        actor.Speed = speed;

        serializedObject.ApplyModifiedProperties();
    }

}
