﻿using UnityEngine;

public class Actor : MonoBehaviour
{
    [HideInInspector]
    public int actorId;
    [HideInInspector]
    public string actorName;

    [Tooltip("武器ID")]
    [Header("左手武器")]
    public int weapon1Id;

    [Tooltip("武器ID")]
    [Header("右手武器")]
    public int weapon2Id;
    [Range(0f, 100f)]
    [Header("血量")]
    public int health;

    #region get/Set
    [SerializeField]
    private int _speed;
    public int Speed
    {
        get
        {
            return _speed;
        }
        set
        {
            if (_speed == value)
                return;
            Debug.Log("set :" + value);
            _speed = value;
        }
    }
    #endregion

    void Start()
    {
        health = 50;
    }

}